$(function(){
	$(".audio").mb_miniPlayer({
		width: 360,
		inLine: false,
		showRew: true,
		showTime: true
	});
});
