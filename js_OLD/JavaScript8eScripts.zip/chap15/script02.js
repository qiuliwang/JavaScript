$(document).ready(function() {
	$("#theMenu").accordion({
		animated: false,
		autoHeight: false,
		header: ".menuLink"
	});
});
